from flask import Flask, request, jsonify
from twilio.rest import Client
from datetime import datetime

import uuid
import logging
import pymysql


import log_config
from log_config import logger
import logging
from logging.handlers import TimedRotatingFileHandler
from decouple import config
import os
from dotenv import load_dotenv
app = Flask(__name__)

load_dotenv()

account_sid = config('account_sid')
auth_token = config('auth_token')

db_host = config('DB_HOST')
db_user = config('DB_USER')
db_password = config('DB_PASSWORD')
db_database = config('DB_DATABASE')

numero_twilio=config('num_twilio')
numero_destino=config('num_destino')


archivos_dir = "reporte_diario.txt" 



proveedores_permitidos = os.environ.get('PROVEEDORES_PERMITIDOS').split(',')
montos_permitidos = [int(monto) for monto in os.environ.get('MONTOS_PERMITIDOS').split(',')]

client = Client(account_sid, auth_token)


transacciones = []
reportes_dir = "reportes"

if not os.path.exists(reportes_dir):
    os.makedirs(reportes_dir)

def obtener_informe_mensual(proveedor, anio, mes):
    mydb = pymysql.connect(
        host=db_host,
        user=db_user,
        password=db_password,
        database=db_database
    )

    mycursor = mydb.cursor()

    try:
        mycursor.callproc("obtener_informe_mensual", (proveedor, anio, mes))
        result = mycursor.fetchall()


        archivo_txt = os.path.join(reportes_dir, f"informe_mensual_usando_StoredProcedure_{proveedor}_{anio}_{mes}.txt")
        print(archivo_txt)
        
    
        with open(archivo_txt, 'w') as file:
            for row in result:
                print(row)
                file.write('\t'.join(map(str, row)) + '\n')

    finally:
        mycursor.close()
        mydb.close()

def obtener_informe_diario(fecha):
    mydb = pymysql.connect(
        host=db_host,
        user=db_user,
        password=db_password,
        database=db_database
    )

    mycursor = mydb.cursor()

    try:
        mycursor.callproc("obtener_informe_diario", (fecha,))
        result = mycursor.fetchall()

       
        archivo_txt = os.path.join(reportes_dir, f"informe_diario_usando_StoredProcedure_{fecha}.txt")

        
        with open(archivo_txt, 'w') as file:
            for row in result:
                file.write('\t'.join(map(str, row)) + '\n')

    finally:
        mycursor.close()
        mydb.close()

def es_recarga_reciente(numero):
    ahora = datetime.now()

    tiempo_de_espera=int(config('wait_message'))
    
    for transaccion in transacciones:
        
        if transaccion['usuario'] == numero and (ahora - transaccion['fecha']).total_seconds() < tiempo_de_espera * 60:
            return True
    return False


@app.route('/realizar_recarga', methods=['POST'])
def realizar_recarga():
    tiempo_de_espera=config('wait_message')
    data = request.get_json()
    proveedor = data.get('proveedor')
    monto = data.get('monto')
    usuario = data.get('usuario')

    if proveedor not in proveedores_permitidos:
        return jsonify({'error': 'Proveedor no permitido'}), 400

    if monto not in montos_permitidos:
        return jsonify({'error': 'Monto no permitido'}), 400

    if es_recarga_reciente(usuario):
        logger.warning(f'Intento de recarga duplicada para el usuario: {usuario}')
        return jsonify({'error': 'Ya se ha realizado una recarga a este número en los últimos '+tiempo_de_espera+ ' minutos'}), 400


    id_transaccion_1 = uuid.uuid4()

    id_transaccion = id_transaccion_1.hex[:16]
    print(id_transaccion)

    mydb = pymysql.connect(
        host=db_host,
        user=db_user,
        password=db_password,
        database=db_database
    )

    mycursor = mydb.cursor()
    folio_para_sql= str(uuid.uuid4())
    sql = "INSERT INTO transacciones (id, proveedor, monto, usuario, fecha_transaccion, folio_transaccion) VALUES (%s, %s, %s, %s, NOW(), %s)"
    val = (id_transaccion, proveedor, monto, usuario,folio_para_sql)

    mycursor.execute(sql, val)

    mydb.commit()

    mycursor.close()
    mydb.close()

  
    for transaccion in transacciones:
        if (transaccion['proveedor'] == proveedor and
            transaccion['usuario'] == usuario and
            transaccion['monto'] == monto):
            return jsonify({'error': 'Esta transacción ya ha sido registrada'}), 400


    transaccion = {
        'proveedor': proveedor,
        'monto': monto,
        'usuario': usuario,
        'fecha': datetime.now(),
        'folio_transaccion': '12345',  # Genera un folio de transacción único
        'estado': 'exitosa'  # Establece el estado de la transacción
    }
    transacciones.append(transaccion)

 
    mensaje = f"Recarga exitosa\nProveedor: {proveedor}\nMonto: ${monto}\nFolio: {folio_para_sql}"
    
   
    mensaje = client.messages.create(
        body=mensaje,
        from_="whatsapp:"+ numero_twilio,  
        to='whatsapp:' + numero_destino 
    )

    logger.info(f'Recarga exitosa realizada para el usuario: {usuario}')
    return jsonify({'message': 'Recarga exitosa', 'folio_transaccion': folio_para_sql}), 201


def transacciones_exitosas_por_proveedor_y_mes(proveedor, anio, mes):
    transacciones_exitosas = []
    for transaccion in transacciones:
        fecha_transaccion = transaccion['fecha']
        if (transaccion['proveedor'] == proveedor and
            fecha_transaccion.year == anio and
            fecha_transaccion.month == mes and
            transaccion.get('estado') == 'exitosa'):
            transacciones_exitosas.append(transaccion)
    return transacciones_exitosas




@app.route('/reporte_transacciones_exitosas/mes/<proveedor>/<anio>/<mes>', methods=['GET'])
def reporte_transacciones_mes(proveedor, anio, mes):
    try:
        anio = int(anio)
        mes = int(mes)
        
        if mes < 1 or mes > 12:
            return jsonify({'error': 'El mes debe estar en el rango de 1 a 12'}), 400
        
        mydb = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_database
        )

        mycursor = mydb.cursor()

        sql = "SELECT proveedor, monto, usuario, fecha_transaccion, folio_transaccion FROM transacciones WHERE proveedor = %s AND YEAR(fecha_transaccion) = %s AND MONTH(fecha_transaccion) = %s"
        val = (proveedor, anio, mes)
        mycursor.execute(sql, val)

        transacciones_exitosas = mycursor.fetchall()

        mycursor.close()
        mydb.close()

        if not transacciones_exitosas:
            logger.info(f'Error no se encontraron reportes mensuales del proveedor {proveedor}')
            return jsonify({'error': 'No se encontraron transacciones exitosas para el proveedor y mes especificados'}), 404


        archivo_txt = f"{reportes_dir}/reporte_{proveedor}_{anio}_{mes}.txt"

        with open(archivo_txt, 'w') as file:
            file.write("Reporte de Transacciones Exitosas del Mes\n")
            file.write(f"Proveedor: {proveedor}\n")
            file.write(f"Año: {anio}\n")
            file.write(f"Mes: {mes}\n\n")
            file.write("Proveedor\tMonto\tUsuario\tFecha\tFolio Transacción\n")
            for transaccion in transacciones_exitosas:
                file.write(f"{transaccion[0]}\t{transaccion[1]}\t{transaccion[2]}\t{transaccion[3]}\t{transaccion[4]}\n")

  
        obtener_informe_mensual(proveedor, anio, mes)
        logger.info(f'Reporte generado de forma exitosa del proveedor: {proveedor}')
        return jsonify({'transacciones_exitosas': transacciones_exitosas, 'archivo_txt': archivo_txt}), 200
    except (ValueError, KeyError):
        return jsonify({'error': 'Formato de fecha o proveedor no válido'}), 400


def transacciones_exitosas_por_dia(fecha):
    transacciones_exitosas = []
    for transaccion in transacciones:
        if (transaccion['fecha'].date() == fecha) and (transaccion.get('estado') == 'exitosa'):
            transacciones_exitosas.append(transaccion)
    return transacciones_exitosas


@app.route('/reporte_transacciones_exitosas/dia/<fecha>', methods=['GET'])
def reporte_transacciones_dia(fecha):
    try:
        
        fecha = datetime.strptime(fecha, "%Y-%m-%d").date()
        print(fecha)
       
        mydb = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_database
        )
        
        mycursor = mydb.cursor()

        sql = "SELECT proveedor, monto, usuario, folio_transaccion FROM transacciones WHERE DATE(fecha_transaccion) = %s"
        val = fecha.strftime('%Y-%m-%d %H:%M:%S')
        print(val) # Añade la hora y el minuto
        mycursor.execute(sql, (val,))
        
        
        transacciones_exitosas = mycursor.fetchall()

        mycursor.close()
        mydb.close()

      
        if not transacciones_exitosas:
            logger.info(f'Error no se encontraron reportes del dia: {fecha}')
            return jsonify({'error': 'No se encontraron transacciones exitosas para la fecha especificada'}), 404
        
        archivo_txt = f"{reportes_dir}/reporte_{fecha}.txt"

        print(fecha)
        
       
        if not transacciones_exitosas:
            return jsonify({'error': 'No se encontraron transacciones exitosas para la fecha especificada'}), 404

        archivo_txt = f"{reportes_dir}/reporte_{fecha}.txt"
        with open(archivo_txt, 'w') as file:
            file.write("Reporte de Transacciones del Día\n")
            file.write(f"Fecha: {fecha.strftime('%Y-%m-%d')}\n\n")  # Formatea la fecha
            file.write("Proveedor\tMonto\tUsuario\tFolio Transacción\n")
            for transaccion in transacciones_exitosas:
                file.write(f"{transaccion[0]}\t{transaccion[1]}\t{transaccion[2]}\t{transaccion[3]}\n")

        
   
        obtener_informe_diario(fecha)
        logger.info(f'Reporte generado de forma exitosa del dia: {fecha}')
        return jsonify({'transacciones_exitosas': transacciones_exitosas, 'archivo_txt': archivo_txt}), 200
    except ValueError:
        print(fecha)
        return jsonify({'error': 'Formato de fecha no válido. Utiliza el formato YYYY-MM-DD'}), 400

if __name__ == '__main__':
    
    app.run(debug=True)
