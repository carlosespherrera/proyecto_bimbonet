import logging
from logging.handlers import TimedRotatingFileHandler
import os
import datetime

# Configura el logger
logger = logging.getLogger('my_logger')
logger.setLevel(logging.DEBUG)

log_dir = 'logs'  # Carpeta para los archivos de logs
current_date = datetime.datetime.now().strftime('%Y-%m-%d')
log_filename = f'my_app_{current_date}.log'

# Crea un manejador para la rotación diaria con límite de 1MB
log_handler = TimedRotatingFileHandler(
    os.path.join(log_dir, log_filename),
    when='midnight',
    interval=1,
    backupCount=7
)
log_handler.suffix = '%Y-%m-%d'
log_handler.extMatch = r'^\d{4}-\d{2}-\d{2}$'

# Configura el formato del log
log_formatter = logging.Formatter('%(asctime)s [%(levelname)s] - %(message)s')
log_handler.setFormatter(log_formatter)

# Agrega el manejador al logger
logger.addHandler(log_handler)
